//
//  ViewController.swift
//  Task1Lab9
//
//  Created by Ivan on 17.04.2020.
//  Copyright © 2020 Ivan. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        MyLabel.textColor=UIColor.white;
        view.backgroundColor=UIColor(patternImage: UIImage(named: "bg1")!);
        
        MyLabel.text="switch is On";
        
        // Do any additional setup after loading the view.
    }

    
    ///Controlling switch change.
    @IBAction func SwitchChanged(_ sender: UISwitch) {
        
        //Changing background according to choosen switch's state
        if(MySwitch.isOn){
            MyLabel.text="switch is On";

    
            view.backgroundColor=UIColor(patternImage: UIImage(named: "bg1")!);

        }
        else{
            MyLabel.text="switch is Off";

            view.backgroundColor=UIColor(patternImage: UIImage(named: "bg2")!);
        }
    }
    
    @IBOutlet weak var MySwitch: UISwitch!
    

    @IBOutlet weak var MyLabel: UILabel!
}

