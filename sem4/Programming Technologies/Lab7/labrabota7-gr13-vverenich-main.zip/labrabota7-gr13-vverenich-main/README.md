# labrabota7-gr13-vverenich
labrabota7-gr13-vverenich created by GitHub Classroom

report:
https://docs.google.com/document/d/18vwVBQGyn8pJlQm_j5M2kPvFKOuwIcx_/edit?usp=sharing&ouid=106168490187212213317&rtpof=true&sd=true
