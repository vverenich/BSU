//
//  ViewController.swift
//  Task4
//
//  Created by Ivan on 18.04.2020.
//  Copyright © 2020 Ivan. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

  override func viewDidLoad() {
           super.viewDidLoad()
           // Do any additional setup after loading the view.
       }

    //Handles pendulum type change
       @IBAction func TypeChanged(_ sender: Any) {
           
           if(TypeField.selectedSegmentIndex==1){
               ParamNameLabel.text = "number";
           }
           else{
               ParamNameLabel.text = "number";
           }
       }
       
    //Solve "calculate" button click
       @IBAction func SolveButtonPressed(_ sender: Any) {
        
           var param = Int(ParamField.text!);
           
           if(TypeField.selectedSegmentIndex==0){
            ResultLabel.text = String(param!, radix: 2);
           }
           else if(TypeField.selectedSegmentIndex==1){
               ResultLabel.text = String(param!, radix: 8);
           }
           else{
               ResultLabel.text = String(param!, radix: 16);
           }
       }
       
       @IBOutlet weak var ResultLabel: UILabel!
       @IBOutlet weak var TypeField: UISegmentedControl!
       @IBOutlet weak var ParamNameLabel: UILabel!
       @IBOutlet weak var ParamField: UITextField!

}

