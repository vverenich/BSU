//
//  ViewController.m
//  Task2Lab7
//
//  Created by Ivan on 17.04.2020.
//  Copyright © 2020 Ivan. All rights reserved.
//

#import "ViewController.h"

///Dicitionary for pairs  <temperature, city>
NSDictionary *faculties;

///Dicitionary for pairs  <temperature, city>
NSDictionary *places;

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
   faculties =[NSMutableDictionary dictionary];
    
    places =[NSMutableDictionary dictionary];
    
    
    
    ///Initializing temperatures dictionary.
    [faculties setValue:[NSNumber numberWithInt:20] forKey:@"Minsk"];
    [faculties setValue:[NSNumber numberWithInt:15] forKey:@"Grodno"];
    [faculties setValue:[NSNumber numberWithInt:16] forKey:@"Kiev"];
    [faculties setValue:[NSNumber numberWithInt:20] forKey:@"Kharkov"];
    
    //Initializing museums dictionary.
      [places setValue:@"Belarussian State University" forKey:@"Minsk"];
      [places setValue:@"Grodno State University" forKey:@"Grodno"];
    [places setValue:@"Kiev Politecnic University" forKey:@"Kiev"];
      [places setValue:@"Kharkov National University" forKey:@"Kharkov"];
    
    // Do any additional setup after loading the view.
}

//Handles confirm button click
- (IBAction)ConfirmButtonClicked:(id)sender {
    
    NSString *cityName= _InputField.text;
    
    NSNumber *numberOfFaculties = [faculties objectForKey:cityName];
    
    NSString *museum=[places objectForKey:cityName];
    
    if(numberOfFaculties==nil){
        _Temperature.text=@"No city found";
    }
    else{
        _Temperature.text=([[numberOfFaculties stringValue] stringByAppendingString:@"  faculties"] );
        
        _MuseumLabel.text=museum;
        _ImageView.image=[UIImage imageNamed:museum];
        
        
        
    }
}

@end
