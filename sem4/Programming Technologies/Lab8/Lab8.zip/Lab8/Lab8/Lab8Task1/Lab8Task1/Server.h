#import "ViewController.h"
#import <UIKit/UIKit.h>

@interface Server:NSObject

+(void) GetBrushRgb:(UIColor*) color Value2: (CGFloat*) r Value3: (CGFloat*) g Value4: (CGFloat*) b Valu5: (CGFloat*) a;
@end






