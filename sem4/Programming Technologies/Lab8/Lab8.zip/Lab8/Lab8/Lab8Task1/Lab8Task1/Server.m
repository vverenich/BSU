#import <Foundation/Foundation.h>
#import "Server.h"

@implementation Server

+(void) GetBrushRgb:(UIColor *)color Value2:(CGFloat *)r Value3:(CGFloat *)g Value4:(CGFloat *)b Valu5:(CGFloat *)a{
    
    [color getRed:r green:g blue:b alpha:a];

};

@end
