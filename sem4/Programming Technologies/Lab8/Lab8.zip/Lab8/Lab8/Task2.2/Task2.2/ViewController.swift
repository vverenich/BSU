import UIKit

class ViewController: UIViewController {

    let options: UIView.AnimationOptions = [.repeat,.autoreverse];
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        

        UIGraphicsBeginImageContext(DrawView.frame.size);
        
        var context=UIGraphicsGetCurrentContext();
        
        context?.setLineWidth(10);
        
        
        FigureDrawer.DrawDecagon(context: context!, x: 200, y: 300, circumRadius: 140);
        
        FigureDrawer.DrawTrapezoid(context: context!, x: 200, y: 400, circumRadius: 70);
        
        
        DrawView.image=UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();
        
    }

    @IBOutlet weak var DrawView: UIImageView!
    
    @IBAction func MoveActivated(_ sender: Any) {
        UIView.animate(withDuration: 3, delay: 0, options: options, animations: {
               
       self.DrawView.transform=self.DrawView.transform.translatedBy(x: 50, y: 0);
           })
    }
    
    @IBAction func SizeActivation(_ sender: Any) {
        UIView.animate(withDuration: 3, delay: 0, options: options, animations: {
                   self.DrawView.frame.size.width*=1.2;
                   self.DrawView.frame.size.height*=1.2;
               })
    }
    
    @IBAction func RotateActivated(_ sender: Any) {
        UIView.animate(withDuration: 3, delay: 0, options: options, animations: {
            
            self.DrawView.transform=self.DrawView.transform.rotated(by: 20);
               })
    }
    
    @IBAction func TransparentActivated(_ sender: Any) {
        UIView.animate(withDuration: 3, delay: 0, options: options, animations: {
                   
            self.DrawView.backgroundColor=self.DrawView.backgroundColor?.withAlphaComponent((self.DrawView.backgroundColor?.cgColor.alpha)!-0.5);
                      })
    }
}

