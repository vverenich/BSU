package com.verenich.Entities;

public abstract class Marrow extends Vegetable {

	public Marrow(double calories, double proteins, double fats, double carbohydrates) {
		super(calories, proteins, fats, carbohydrates);
		// TODO Auto-generated constructor stub
	}
	
}
