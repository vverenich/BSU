package com.verenich.Entities;

public abstract class Allium extends Vegetable {

	public Allium(double calories, double proteins, double fats, double carbohydrates) {
		super(calories, proteins, fats, carbohydrates);
		// TODO Auto-generated constructor stub
	}
	
}

