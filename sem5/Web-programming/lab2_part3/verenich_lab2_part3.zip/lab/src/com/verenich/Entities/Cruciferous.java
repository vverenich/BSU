package com.verenich.Entities;

public abstract class Cruciferous extends Vegetable {

	public Cruciferous(double calories, double proteins, double fats, double carbohydrates) {
		super(calories, proteins, fats, carbohydrates);
		// TODO Auto-generated constructor stub
	}
	
}
