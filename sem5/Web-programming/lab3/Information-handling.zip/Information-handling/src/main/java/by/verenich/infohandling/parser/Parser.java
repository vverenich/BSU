package by.verenich.infohandling.parser;

import by.verenich.infohandling.composite.Component;
import by.verenich.infohandling.exception.InformationHandlingException;

/**
 * Parse text to components using regex
 */
public interface Parser {

    /**
     * parse text to composite by regex
     * 
     * @param text the source text
     * @param regex
     * @return
     * @throws InformationHandlingException
     */
    Component parse(String text) throws InformationHandlingException;
}
