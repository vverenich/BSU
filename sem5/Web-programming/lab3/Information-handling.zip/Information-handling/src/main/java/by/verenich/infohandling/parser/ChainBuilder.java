package by.verenich.infohandling.parser;
/* 
import by.verenich.infohandling.parser.ParagraphParser;
import by.verenich.infohandling.parser.Parser;
import by.verenich.infohandling.parser.SentenceParser;
import by.verenich.infohandling.parser.TextParser;
*/

/**
 * Uses to connect parsers
 */
public class ChainBuilder {

    
    /** 
     * @return Parser
     */
    public Parser build() {
        return new TextParser(new ParagraphParser(new SentenceParser(null)));
    }
}
