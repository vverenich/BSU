package by.verenich.infohandling.parser;

import by.verenich.infohandling.composite.Component;
import by.verenich.infohandling.composite.Composite;
import by.verenich.infohandling.composite.Lexeme;
import by.verenich.infohandling.exception.InformationHandlingException;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SentenceParser extends AbstractParser {

    private static final String EXPRESSION_REGEX = "\\[.+?\\]";
    private static final String WORD_REGEX = "[\\p{Alpha}\\p{Punct}]+";

    private static final String LEXEME_REGEX = 
        String.format("%s|%s", EXPRESSION_REGEX, WORD_REGEX);

    public SentenceParser(Parser successor) {
        super(successor);
    }

    /**
     * parse text to words by sentence regex
     */
    @Override
    public Component parse(String text) throws InformationHandlingException {
        Composite composite = new Composite();
        Pattern pattern = Pattern.compile(LEXEME_REGEX);
        Matcher matcher = pattern.matcher(text);

        while (matcher.find()) {
            String lexemeString = matcher.group();
            Lexeme lexeme = null;
            if (lexemeString.matches(EXPRESSION_REGEX)) {
                lexeme = Lexeme.expression(lexemeString);
            } else if (lexemeString.matches(WORD_REGEX)) {
                lexeme = Lexeme.word(lexemeString);
            } else {
                throw new InformationHandlingException("Unknown lexeme");
            }

            composite.add(lexeme);
        }

        return composite;
    }
}
