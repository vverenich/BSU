package by.verenich.infohandling.parser;

import by.verenich.infohandling.composite.Component;
import by.verenich.infohandling.composite.Composite;
import by.verenich.infohandling.exception.InformationHandlingException;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/* 
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
*/


public abstract class AbstractParser implements Parser {
    
    private Parser successor;

    public AbstractParser(Parser successor) {
        this.successor = successor;
    }

    
    /** 
     * @return Parser
     */
    protected Parser getSuccessor() {
        return successor;
    }

    
    /** 
     * @param text
     * @param regex
     * @return Component
     * @throws InformationHandlingException
     */
    protected Component parseByRegex(String text, String regex) throws InformationHandlingException {
        Composite composite = new Composite();
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(text);

        while (matcher.find()) {
            String part = matcher.group();
            Component component = getSuccessor().parse(part);
            composite.add(component);
        }

        return composite;
    }
}
