package by.verenich.infohandling.composite;

/**
 * Component of which can be leaf or composite
 */
public interface Component {
    int size();
}
