package by.verenich.infohandling.composite;

import lombok.Value;

/**
 * Leaf component of composite
 */
@Value
public class Lexeme implements Component {

    String value;
    LexemeType type;

    public Lexeme(String value, LexemeType type) {
        this.value = value;
        this.type = type;
    }

    
    /** 
     * @param value
     * @return Lexeme
     */
    public static Lexeme word(String value) {
        return new Lexeme(value, LexemeType.WORD);
    }

    
    /** 
     * @param value
     * @return Lexeme
     */
    public static Lexeme expression(String value) {
        return new Lexeme(value, LexemeType.EXPRESSION);
    }

    
    /** 
     * @return boolean
     */
    public boolean isWord() {
        return type == LexemeType.WORD;
    }

    
    /** 
     * @return boolean
     */
    public boolean isExpression() {
        return type == LexemeType.EXPRESSION;
    }

    
    /** 
     * @return int
     */
    @Override
    public int size() {
        return value.length();
    }

    
    /** 
     * @return String
     */
    public String toString() {
        return this.getValue();
    }
}
