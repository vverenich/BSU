package by.verenich.infohandling.logic;

import by.verenich.infohandling.composite.Component;
import by.verenich.infohandling.composite.Composite;
import by.verenich.infohandling.composite.Lexeme;
//import by.verenich.infohandling.composite.LexemeType;
import by.verenich.infohandling.exception.InformationHandlingException;
import by.verenich.infohandling.parser.ChainBuilder;
import by.verenich.infohandling.parser.Parser;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.ArrayList;
//import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.TreeSet;
//import java.util.Map;
import java.util.regex.MatchResult;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
//import java.util.stream.Collectors;

public class TextLogic {
    private static final Logger LOGGER = LogManager.getLogger(TextLogic.class);

    public Component parse(String text) throws InformationHandlingException {
        ChainBuilder chainBuilder = new ChainBuilder();
        Parser parser = chainBuilder.build();

        return parser.parse(text);
    }

    public String restoreText(Composite text) {
        StringBuilder stringBuilder = new StringBuilder();
        for (Component paragraph : text.getComponents()) {
            restore(paragraph, stringBuilder);
            stringBuilder.append('\n');
        }

        return String.valueOf(stringBuilder);
    }


    // recursive function
    private void restore(Component component, StringBuilder stringBuilder) {
        if (component.getClass() == Lexeme.class) {
            Lexeme lexeme = (Lexeme) component;
            stringBuilder.append(lexeme);
            return;
        }

        Composite composite = (Composite) component;
        for (Component childComponent : composite.getComponents()) {
            restore(childComponent, stringBuilder);
            stringBuilder.append(' ');
        }
    }

    
    public List<Lexeme> sortSentenceByVowelsAmount(Composite text) {
        Comparator<Lexeme> vowelComparator = (Lexeme l1, Lexeme l2) -> {
            if (!l1.isWord() && !l2.isWord()) {
                return 0;
            } else if (!l1.isWord()) {
                return -1;
            } else if (!l2.isWord()) {
                return 1;
            }

            String vowelRegex = "[aeuoyiAEYUOI]";
            Pattern pattern = Pattern.compile(vowelRegex);
            
            String firstWord = l1.getValue();
            Matcher firstWordVowelMatcher = pattern.matcher(firstWord);
            long firstWordVowelCount = firstWordVowelMatcher.results().count();
            Long firstWordTotalLetterAmount = Long.valueOf(firstWord.length());
            Double firstWordVowelPart = Double.valueOf(firstWordVowelCount) / firstWordTotalLetterAmount;

            String secondWord = l2.getValue();
            Matcher secondWordVowelMatcher = pattern.matcher(secondWord);
            long secondWordVowelCount = secondWordVowelMatcher.results().count();
            Long secondWordTotalLetterAmount = Long.valueOf(secondWord.length());
            Double secondWordVowelPart = Double.valueOf(secondWordVowelCount) / secondWordTotalLetterAmount;

            return Double.compare(firstWordVowelPart, secondWordVowelPart);
        };
        
        List<Lexeme> lexemes = new ArrayList<>();
        for (Component paragraphComponent : text.getComponents()) {
            Composite paragraph = (Composite) paragraphComponent;

            for (Component sentenceComponent : paragraph.getComponents()) {
                Composite sentence = (Composite) sentenceComponent;

                List<Lexeme> lexemeInSentence = sentence.getComponents().stream()
                        .map(Lexeme.class::cast)
                        .toList();

                lexemes.addAll(lexemeInSentence);
            }
        }

        lexemes.sort(vowelComparator);

        return lexemes;
    }


    public String findSubstringWithoutLetters(Composite composite) {
        String text = restoreText(composite);
        String notLetterRegex = "[^\\p{Alpha}а-яА-Я]+";
        Pattern pattern = Pattern.compile(notLetterRegex);
        return pattern
                .matcher(text)
                .results()
                .map(MatchResult::group)
                .max(Comparator.comparingInt(String::length))
                .orElse("");
    }
}
