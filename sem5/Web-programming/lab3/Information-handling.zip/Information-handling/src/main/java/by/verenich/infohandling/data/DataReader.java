package by.verenich.infohandling.data;

import by.verenich.infohandling.exception.DataException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

/**
 * Read date from file
 */
public class DataReader {
    private static final Logger LOGGER = LogManager.getLogger(DataReader.class);

    private static final String LINE_FEED = "\n";

    
    /** 
     * @param filePath
     * @return String
     * @throws DataException
     */
    public String read(String filePath) throws DataException {
        LOGGER.debug("Reading from file: " + filePath);

        StringBuilder text = new StringBuilder();

        try (FileReader fileReader = new FileReader(filePath);
             BufferedReader bufferedReader = new BufferedReader(fileReader)) {

            for (String line = bufferedReader.readLine(); line != null; line = bufferedReader.readLine()) {
                text.append(line).append(LINE_FEED);
            }

        } catch (IOException ex) {
            throw new DataException("File reading exception", ex);
        }

        return String.valueOf(text);
    }
}
