package by.verenich.infohandling.logic;

import java.util.List;

import by.verenich.infohandling.composite.Component;

import by.verenich.infohandling.composite.Composite;
import by.verenich.infohandling.composite.Lexeme;
import by.verenich.infohandling.exception.InformationHandlingException;

 /** 
  * @throws InformationHandlingException
  */
public class Main {
    public static void main(String[] args) throws InformationHandlingException{

        TextLogic textLogic = new TextLogic();

        String text = String.format("%s %s %s %s %s %s %s",
            "Late one night the boys woke from the same dreadfully bad dream.",
            "They scrambled to their feet all at once.",
            "The moon seemed unusually large.",
            "The stars shone uncomfortably bright.",
            "The sky felt dangerously close. ",
            "Half the boys pressed down against the earth.",
            "Half the boys held up the sky."
        );

        System.out.print("Initial text:\n");
        System.out.println(text);
        
        Composite textComposite = (Composite)textLogic.parse(text);

        // System.out.print("Lexemes:\n\n");
        // for (Component paragraph : textComposite.getComponents()) {
        //     Composite paragraphComposite = (Composite) paragraph;
        //     for (Component sentence : paragraphComposite.getComponents()) {
        //         Composite sentenceComposite = (Composite) sentence;
        //         sentenceComposite.getComponents()
        //             .stream()
        //             .map(Lexeme.class::cast)
        //             .forEach(lexeme -> {
        //                 System.out.print(lexeme + ", ");
        //             });
        //     }
        // }

        String restoredText = textLogic.restoreText(textComposite);
        System.out.println("\n\nRestored text:\n");
        System.out.println(restoredText);

        List<Lexeme> textSortedComposite = textLogic.sortSentenceByVowelsAmount(textComposite);
        System.out.println("\nSorted text:\n");
        for (Lexeme lexeme : textSortedComposite) {
            System.out.print(lexeme + " ");
        };
    }
}
