package by.verenich.infohandling.parser;

import by.verenich.infohandling.composite.Component;
import by.verenich.infohandling.exception.InformationHandlingException;

public class TextParser extends AbstractParser {

    private static final String PARAGRAPH_REGEX = "[^\\n]+(?:\\n+|$)";

    public TextParser(Parser successor) {
        super(successor);
    }

    /**
     * parse text to paragraphs by sentence regex
     */
    @Override
    public Component parse(String text) throws InformationHandlingException {
        return super.parseByRegex(text, PARAGRAPH_REGEX);
    }
}
