package by.verenich.infohandling.composite;

public enum LexemeType {
    WORD, EXPRESSION
}
