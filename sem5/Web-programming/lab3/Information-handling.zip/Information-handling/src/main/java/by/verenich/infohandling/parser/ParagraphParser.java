package by.verenich.infohandling.parser;

import by.verenich.infohandling.composite.Component;
import by.verenich.infohandling.exception.InformationHandlingException;

public class ParagraphParser extends AbstractParser {

    private static final String SENTENCE_REGEX = "(\\p{Upper}|\\p{Digit}).+?[.!?]";

    public ParagraphParser(Parser successor) {
        super(successor);
    }

    /**
     * parse text to seneteces by sentence regex
     */
    @Override
    public Component parse(String text) throws InformationHandlingException {
        return super.parseByRegex(text, SENTENCE_REGEX);
    }
}
