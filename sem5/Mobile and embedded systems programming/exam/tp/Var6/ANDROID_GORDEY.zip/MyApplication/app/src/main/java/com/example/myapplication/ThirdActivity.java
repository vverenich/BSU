package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Button;

public class ThirdActivity extends AppCompatActivity {

    private EditText dateEditText;
    private EditText placeEditText;
    private Button backButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third);

        dateEditText = findViewById(R.id.dateEditText);
        placeEditText = findViewById(R.id.placeEditText);
    }

    public void openSecondFromThird(View view) {

        String date = dateEditText.getText().toString();
        String place = placeEditText.getText().toString();

        SharedPreferences sharedPreferences = getSharedPreferences("ID", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("date", date);
        editor.putString("place", place);
        editor.apply();

        Intent intent = new Intent(this, SecondActivity.class);
        startActivity(intent);
    }
}
