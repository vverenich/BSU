package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText phoneEditText;
    private EditText nameEditText;
    private EditText surnameEditText;
    private Button registerBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        phoneEditText = findViewById(R.id.phoneEditText);
        nameEditText = findViewById(R.id.nameEditText);
        surnameEditText = findViewById(R.id.surnameEditText);
        registerBtn = findViewById(R.id.registerButton);

        SharedPreferences sharedPreferences = getSharedPreferences("ID", MODE_PRIVATE);
        if (sharedPreferences.getString("name",null) != null && sharedPreferences.getString("surname",null) != null) {
            registerBtn.setText("Login");
        }

    }

    public void openSecondFromFirstActivity(View view) {
        String phone = phoneEditText.getText().toString();
        String name = nameEditText.getText().toString();
        String surname = surnameEditText.getText().toString();

        SharedPreferences sharedPreferences = getSharedPreferences("ID", MODE_PRIVATE);

        if (registerBtn.getText() == "Login"){
            if (!((sharedPreferences.getString("name",null).equals(name) &&
                (sharedPreferences.getString("surname",null).equals(surname))&&
                (sharedPreferences.getString("phone",null).equals(phone))))) {
                Toast.makeText(getApplicationContext(), //Context
                        "Incorrect Data!", // Message to display
                        Toast.LENGTH_SHORT // Duration of the message, another possible value is Toast.LENGTH_LONG
                ).show();
            } else {
                Intent intent = new Intent(this, SecondActivity.class);
                startActivity(intent);
            }
        } else {
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putString("phone", phone);
            editor.putString("name", name);
            editor.putString("surname", surname);
            editor.apply();
            Intent intent = new Intent(this, SecondActivity.class);
            startActivity(intent);
        }


    }
}
