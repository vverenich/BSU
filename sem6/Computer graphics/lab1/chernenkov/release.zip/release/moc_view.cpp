/****************************************************************************
** Meta object code from reading C++ file 'view.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../ColorConverter/view.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'view.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_View_t {
    QByteArrayData data[58];
    char stringdata0[946];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_View_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_View_t qt_meta_stringdata_View = {
    {
QT_MOC_LITERAL(0, 0, 4), // "View"
QT_MOC_LITERAL(1, 5, 21), // "sliderRedValueChanged"
QT_MOC_LITERAL(2, 27, 0), // ""
QT_MOC_LITERAL(3, 28, 23), // "sliderGreenValueChanged"
QT_MOC_LITERAL(4, 52, 22), // "sliderBlueValueChanged"
QT_MOC_LITERAL(5, 75, 24), // "textFieldRedValueChanged"
QT_MOC_LITERAL(6, 100, 26), // "textFieldGreenValueChanged"
QT_MOC_LITERAL(7, 127, 25), // "textFieldBlueValueChanged"
QT_MOC_LITERAL(8, 153, 24), // "textFieldHueValueChanged"
QT_MOC_LITERAL(9, 178, 31), // "textFieldSaturationValueChanged"
QT_MOC_LITERAL(10, 210, 30), // "textFieldLightnessValueChanged"
QT_MOC_LITERAL(11, 241, 22), // "textFieldCValueChanged"
QT_MOC_LITERAL(12, 264, 22), // "textFieldMValueChanged"
QT_MOC_LITERAL(13, 287, 22), // "textFieldYValueChanged"
QT_MOC_LITERAL(14, 310, 22), // "textFieldKValueChanged"
QT_MOC_LITERAL(15, 333, 21), // "rectangleColorChanged"
QT_MOC_LITERAL(16, 355, 17), // "setSliderRedValue"
QT_MOC_LITERAL(17, 373, 5), // "value"
QT_MOC_LITERAL(18, 379, 19), // "setSliderGreenValue"
QT_MOC_LITERAL(19, 399, 18), // "setSliderBlueValue"
QT_MOC_LITERAL(20, 418, 20), // "setTextFieldRedValue"
QT_MOC_LITERAL(21, 439, 22), // "setTextFieldGreenValue"
QT_MOC_LITERAL(22, 462, 21), // "setTextFieldBlueValue"
QT_MOC_LITERAL(23, 484, 20), // "setTextFieldHueValue"
QT_MOC_LITERAL(24, 505, 1), // "h"
QT_MOC_LITERAL(25, 507, 1), // "s"
QT_MOC_LITERAL(26, 509, 1), // "v"
QT_MOC_LITERAL(27, 511, 27), // "setTextFieldSaturationValue"
QT_MOC_LITERAL(28, 539, 26), // "setTextFieldLightnessValue"
QT_MOC_LITERAL(29, 566, 18), // "setTextFieldCValue"
QT_MOC_LITERAL(30, 585, 1), // "l"
QT_MOC_LITERAL(31, 587, 1), // "a"
QT_MOC_LITERAL(32, 589, 1), // "b"
QT_MOC_LITERAL(33, 591, 18), // "setTextFieldMValue"
QT_MOC_LITERAL(34, 610, 18), // "setTextFieldYValue"
QT_MOC_LITERAL(35, 629, 18), // "setTextFieldKValue"
QT_MOC_LITERAL(36, 648, 6), // "setHSL"
QT_MOC_LITERAL(37, 655, 7), // "setCMYK"
QT_MOC_LITERAL(38, 663, 1), // "c"
QT_MOC_LITERAL(39, 665, 1), // "m"
QT_MOC_LITERAL(40, 667, 1), // "y"
QT_MOC_LITERAL(41, 669, 1), // "k"
QT_MOC_LITERAL(42, 671, 17), // "setRectangleColor"
QT_MOC_LITERAL(43, 689, 5), // "color"
QT_MOC_LITERAL(44, 695, 14), // "sliderRedValue"
QT_MOC_LITERAL(45, 710, 16), // "sliderGreenValue"
QT_MOC_LITERAL(46, 727, 15), // "sliderBlueValue"
QT_MOC_LITERAL(47, 743, 17), // "textFieldRedValue"
QT_MOC_LITERAL(48, 761, 19), // "textFieldGreenValue"
QT_MOC_LITERAL(49, 781, 18), // "textFieldBlueValue"
QT_MOC_LITERAL(50, 800, 17), // "textFieldHueValue"
QT_MOC_LITERAL(51, 818, 24), // "textFieldSaturationValue"
QT_MOC_LITERAL(52, 843, 23), // "textFieldLightnessValue"
QT_MOC_LITERAL(53, 867, 15), // "textFieldCValue"
QT_MOC_LITERAL(54, 883, 15), // "textFieldMValue"
QT_MOC_LITERAL(55, 899, 15), // "textFieldYValue"
QT_MOC_LITERAL(56, 915, 15), // "textFieldKValue"
QT_MOC_LITERAL(57, 931, 14) // "rectangleColor"

    },
    "View\0sliderRedValueChanged\0\0"
    "sliderGreenValueChanged\0sliderBlueValueChanged\0"
    "textFieldRedValueChanged\0"
    "textFieldGreenValueChanged\0"
    "textFieldBlueValueChanged\0"
    "textFieldHueValueChanged\0"
    "textFieldSaturationValueChanged\0"
    "textFieldLightnessValueChanged\0"
    "textFieldCValueChanged\0textFieldMValueChanged\0"
    "textFieldYValueChanged\0textFieldKValueChanged\0"
    "rectangleColorChanged\0setSliderRedValue\0"
    "value\0setSliderGreenValue\0setSliderBlueValue\0"
    "setTextFieldRedValue\0setTextFieldGreenValue\0"
    "setTextFieldBlueValue\0setTextFieldHueValue\0"
    "h\0s\0v\0setTextFieldSaturationValue\0"
    "setTextFieldLightnessValue\0"
    "setTextFieldCValue\0l\0a\0b\0setTextFieldMValue\0"
    "setTextFieldYValue\0setTextFieldKValue\0"
    "setHSL\0setCMYK\0c\0m\0y\0k\0setRectangleColor\0"
    "color\0sliderRedValue\0sliderGreenValue\0"
    "sliderBlueValue\0textFieldRedValue\0"
    "textFieldGreenValue\0textFieldBlueValue\0"
    "textFieldHueValue\0textFieldSaturationValue\0"
    "textFieldLightnessValue\0textFieldCValue\0"
    "textFieldMValue\0textFieldYValue\0"
    "textFieldKValue\0rectangleColor"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_View[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      37,   14, // methods
      14,  320, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
      14,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,  199,    2, 0x06 /* Public */,
       3,    0,  200,    2, 0x06 /* Public */,
       4,    0,  201,    2, 0x06 /* Public */,
       5,    0,  202,    2, 0x06 /* Public */,
       6,    0,  203,    2, 0x06 /* Public */,
       7,    0,  204,    2, 0x06 /* Public */,
       8,    0,  205,    2, 0x06 /* Public */,
       9,    0,  206,    2, 0x06 /* Public */,
      10,    0,  207,    2, 0x06 /* Public */,
      11,    0,  208,    2, 0x06 /* Public */,
      12,    0,  209,    2, 0x06 /* Public */,
      13,    0,  210,    2, 0x06 /* Public */,
      14,    0,  211,    2, 0x06 /* Public */,
      15,    0,  212,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      16,    1,  213,    2, 0x0a /* Public */,
      18,    1,  216,    2, 0x0a /* Public */,
      19,    1,  219,    2, 0x0a /* Public */,
      20,    1,  222,    2, 0x0a /* Public */,
      21,    1,  225,    2, 0x0a /* Public */,
      22,    1,  228,    2, 0x0a /* Public */,
      23,    3,  231,    2, 0x0a /* Public */,
      27,    3,  238,    2, 0x0a /* Public */,
      28,    3,  245,    2, 0x0a /* Public */,
      23,    1,  252,    2, 0x0a /* Public */,
      27,    1,  255,    2, 0x0a /* Public */,
      28,    1,  258,    2, 0x0a /* Public */,
      29,    3,  261,    2, 0x0a /* Public */,
      33,    3,  268,    2, 0x0a /* Public */,
      34,    3,  275,    2, 0x0a /* Public */,
      35,    3,  282,    2, 0x0a /* Public */,
      29,    1,  289,    2, 0x0a /* Public */,
      33,    1,  292,    2, 0x0a /* Public */,
      34,    1,  295,    2, 0x0a /* Public */,
      35,    1,  298,    2, 0x0a /* Public */,
      36,    3,  301,    2, 0x0a /* Public */,
      37,    4,  308,    2, 0x0a /* Public */,
      42,    1,  317,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void, QMetaType::Float, QMetaType::Float, QMetaType::Float,   24,   25,   26,
    QMetaType::Void, QMetaType::Float, QMetaType::Float, QMetaType::Float,   24,   25,   26,
    QMetaType::Void, QMetaType::Float, QMetaType::Float, QMetaType::Float,   24,   25,   26,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void, QMetaType::Float, QMetaType::Float, QMetaType::Float,   30,   31,   32,
    QMetaType::Void, QMetaType::Float, QMetaType::Float, QMetaType::Float,   30,   31,   32,
    QMetaType::Void, QMetaType::Float, QMetaType::Float, QMetaType::Float,   30,   31,   32,
    QMetaType::Void, QMetaType::Float, QMetaType::Float, QMetaType::Float,   30,   31,   32,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void, QMetaType::Float, QMetaType::Float, QMetaType::Float,   24,   25,   30,
    QMetaType::Void, QMetaType::Float, QMetaType::Float, QMetaType::Float, QMetaType::Float,   38,   39,   40,   41,
    QMetaType::Void, QMetaType::QColor,   43,

 // properties: name, type, flags
      44, QMetaType::Int, 0x00495103,
      45, QMetaType::Int, 0x00495103,
      46, QMetaType::Int, 0x00495103,
      47, QMetaType::Int, 0x00495103,
      48, QMetaType::Int, 0x00495103,
      49, QMetaType::Int, 0x00495103,
      50, QMetaType::Int, 0x00495103,
      51, QMetaType::Int, 0x00495103,
      52, QMetaType::Int, 0x00495103,
      53, QMetaType::Int, 0x00495103,
      54, QMetaType::Int, 0x00495103,
      55, QMetaType::Int, 0x00495103,
      56, QMetaType::Int, 0x00495103,
      57, QMetaType::QColor, 0x00495103,

 // properties: notify_signal_id
       0,
       1,
       2,
       3,
       4,
       5,
       6,
       7,
       8,
       9,
      10,
      11,
      12,
      13,

       0        // eod
};

void View::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<View *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->sliderRedValueChanged(); break;
        case 1: _t->sliderGreenValueChanged(); break;
        case 2: _t->sliderBlueValueChanged(); break;
        case 3: _t->textFieldRedValueChanged(); break;
        case 4: _t->textFieldGreenValueChanged(); break;
        case 5: _t->textFieldBlueValueChanged(); break;
        case 6: _t->textFieldHueValueChanged(); break;
        case 7: _t->textFieldSaturationValueChanged(); break;
        case 8: _t->textFieldLightnessValueChanged(); break;
        case 9: _t->textFieldCValueChanged(); break;
        case 10: _t->textFieldMValueChanged(); break;
        case 11: _t->textFieldYValueChanged(); break;
        case 12: _t->textFieldKValueChanged(); break;
        case 13: _t->rectangleColorChanged(); break;
        case 14: _t->setSliderRedValue((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 15: _t->setSliderGreenValue((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 16: _t->setSliderBlueValue((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 17: _t->setTextFieldRedValue((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 18: _t->setTextFieldGreenValue((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 19: _t->setTextFieldBlueValue((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 20: _t->setTextFieldHueValue((*reinterpret_cast< float(*)>(_a[1])),(*reinterpret_cast< float(*)>(_a[2])),(*reinterpret_cast< float(*)>(_a[3]))); break;
        case 21: _t->setTextFieldSaturationValue((*reinterpret_cast< float(*)>(_a[1])),(*reinterpret_cast< float(*)>(_a[2])),(*reinterpret_cast< float(*)>(_a[3]))); break;
        case 22: _t->setTextFieldLightnessValue((*reinterpret_cast< float(*)>(_a[1])),(*reinterpret_cast< float(*)>(_a[2])),(*reinterpret_cast< float(*)>(_a[3]))); break;
        case 23: _t->setTextFieldHueValue((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 24: _t->setTextFieldSaturationValue((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 25: _t->setTextFieldLightnessValue((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 26: _t->setTextFieldCValue((*reinterpret_cast< float(*)>(_a[1])),(*reinterpret_cast< float(*)>(_a[2])),(*reinterpret_cast< float(*)>(_a[3]))); break;
        case 27: _t->setTextFieldMValue((*reinterpret_cast< float(*)>(_a[1])),(*reinterpret_cast< float(*)>(_a[2])),(*reinterpret_cast< float(*)>(_a[3]))); break;
        case 28: _t->setTextFieldYValue((*reinterpret_cast< float(*)>(_a[1])),(*reinterpret_cast< float(*)>(_a[2])),(*reinterpret_cast< float(*)>(_a[3]))); break;
        case 29: _t->setTextFieldKValue((*reinterpret_cast< float(*)>(_a[1])),(*reinterpret_cast< float(*)>(_a[2])),(*reinterpret_cast< float(*)>(_a[3]))); break;
        case 30: _t->setTextFieldCValue((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 31: _t->setTextFieldMValue((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 32: _t->setTextFieldYValue((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 33: _t->setTextFieldKValue((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 34: _t->setHSL((*reinterpret_cast< float(*)>(_a[1])),(*reinterpret_cast< float(*)>(_a[2])),(*reinterpret_cast< float(*)>(_a[3]))); break;
        case 35: _t->setCMYK((*reinterpret_cast< float(*)>(_a[1])),(*reinterpret_cast< float(*)>(_a[2])),(*reinterpret_cast< float(*)>(_a[3])),(*reinterpret_cast< float(*)>(_a[4]))); break;
        case 36: _t->setRectangleColor((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (View::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&View::sliderRedValueChanged)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (View::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&View::sliderGreenValueChanged)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (View::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&View::sliderBlueValueChanged)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (View::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&View::textFieldRedValueChanged)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (View::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&View::textFieldGreenValueChanged)) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (View::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&View::textFieldBlueValueChanged)) {
                *result = 5;
                return;
            }
        }
        {
            using _t = void (View::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&View::textFieldHueValueChanged)) {
                *result = 6;
                return;
            }
        }
        {
            using _t = void (View::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&View::textFieldSaturationValueChanged)) {
                *result = 7;
                return;
            }
        }
        {
            using _t = void (View::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&View::textFieldLightnessValueChanged)) {
                *result = 8;
                return;
            }
        }
        {
            using _t = void (View::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&View::textFieldCValueChanged)) {
                *result = 9;
                return;
            }
        }
        {
            using _t = void (View::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&View::textFieldMValueChanged)) {
                *result = 10;
                return;
            }
        }
        {
            using _t = void (View::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&View::textFieldYValueChanged)) {
                *result = 11;
                return;
            }
        }
        {
            using _t = void (View::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&View::textFieldKValueChanged)) {
                *result = 12;
                return;
            }
        }
        {
            using _t = void (View::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&View::rectangleColorChanged)) {
                *result = 13;
                return;
            }
        }
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        auto *_t = static_cast<View *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< int*>(_v) = _t->getSliderRedValue(); break;
        case 1: *reinterpret_cast< int*>(_v) = _t->getSliderGreenValue(); break;
        case 2: *reinterpret_cast< int*>(_v) = _t->getSliderBlueValue(); break;
        case 3: *reinterpret_cast< int*>(_v) = _t->getTextFieldRedValue(); break;
        case 4: *reinterpret_cast< int*>(_v) = _t->getTextFieldGreenValue(); break;
        case 5: *reinterpret_cast< int*>(_v) = _t->getTextFieldBlueValue(); break;
        case 6: *reinterpret_cast< int*>(_v) = _t->getTextFieldHueValue(); break;
        case 7: *reinterpret_cast< int*>(_v) = _t->getTextFieldSaturationValue(); break;
        case 8: *reinterpret_cast< int*>(_v) = _t->getTextFieldLightnessValue(); break;
        case 9: *reinterpret_cast< int*>(_v) = _t->getTextFieldCValue(); break;
        case 10: *reinterpret_cast< int*>(_v) = _t->getTextFieldMValue(); break;
        case 11: *reinterpret_cast< int*>(_v) = _t->getTextFieldYValue(); break;
        case 12: *reinterpret_cast< int*>(_v) = _t->getTextFieldKValue(); break;
        case 13: *reinterpret_cast< QColor*>(_v) = _t->getRectangleColor(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        auto *_t = static_cast<View *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setSliderRedValue(*reinterpret_cast< int*>(_v)); break;
        case 1: _t->setSliderGreenValue(*reinterpret_cast< int*>(_v)); break;
        case 2: _t->setSliderBlueValue(*reinterpret_cast< int*>(_v)); break;
        case 3: _t->setTextFieldRedValue(*reinterpret_cast< int*>(_v)); break;
        case 4: _t->setTextFieldGreenValue(*reinterpret_cast< int*>(_v)); break;
        case 5: _t->setTextFieldBlueValue(*reinterpret_cast< int*>(_v)); break;
        case 6: _t->setTextFieldHueValue(*reinterpret_cast< int*>(_v)); break;
        case 7: _t->setTextFieldSaturationValue(*reinterpret_cast< int*>(_v)); break;
        case 8: _t->setTextFieldLightnessValue(*reinterpret_cast< int*>(_v)); break;
        case 9: _t->setTextFieldCValue(*reinterpret_cast< int*>(_v)); break;
        case 10: _t->setTextFieldMValue(*reinterpret_cast< int*>(_v)); break;
        case 11: _t->setTextFieldYValue(*reinterpret_cast< int*>(_v)); break;
        case 12: _t->setTextFieldKValue(*reinterpret_cast< int*>(_v)); break;
        case 13: _t->setRectangleColor(*reinterpret_cast< QColor*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
}

QT_INIT_METAOBJECT const QMetaObject View::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_View.data,
    qt_meta_data_View,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *View::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *View::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_View.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int View::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 37)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 37;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 37)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 37;
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 14;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 14;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 14;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 14;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 14;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 14;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void View::sliderRedValueChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void View::sliderGreenValueChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void View::sliderBlueValueChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}

// SIGNAL 3
void View::textFieldRedValueChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 3, nullptr);
}

// SIGNAL 4
void View::textFieldGreenValueChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 4, nullptr);
}

// SIGNAL 5
void View::textFieldBlueValueChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 5, nullptr);
}

// SIGNAL 6
void View::textFieldHueValueChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 6, nullptr);
}

// SIGNAL 7
void View::textFieldSaturationValueChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 7, nullptr);
}

// SIGNAL 8
void View::textFieldLightnessValueChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 8, nullptr);
}

// SIGNAL 9
void View::textFieldCValueChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 9, nullptr);
}

// SIGNAL 10
void View::textFieldMValueChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 10, nullptr);
}

// SIGNAL 11
void View::textFieldYValueChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 11, nullptr);
}

// SIGNAL 12
void View::textFieldKValueChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 12, nullptr);
}

// SIGNAL 13
void View::rectangleColorChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 13, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
