/****************************************************************************
** Meta object code from reading C++ file 'view.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../../lab1/project/ColorConverter/view.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'view.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_View_t {
    QByteArrayData data[49];
    char stringdata0[853];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_View_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_View_t qt_meta_stringdata_View = {
    {
QT_MOC_LITERAL(0, 0, 4), // "View"
QT_MOC_LITERAL(1, 5, 21), // "sliderRedValueChanged"
QT_MOC_LITERAL(2, 27, 0), // ""
QT_MOC_LITERAL(3, 28, 23), // "sliderGreenValueChanged"
QT_MOC_LITERAL(4, 52, 22), // "sliderBlueValueChanged"
QT_MOC_LITERAL(5, 75, 24), // "textFieldRedValueChanged"
QT_MOC_LITERAL(6, 100, 26), // "textFieldGreenValueChanged"
QT_MOC_LITERAL(7, 127, 25), // "textFieldBlueValueChanged"
QT_MOC_LITERAL(8, 153, 24), // "textFieldHueValueChanged"
QT_MOC_LITERAL(9, 178, 31), // "textFieldSaturationValueChanged"
QT_MOC_LITERAL(10, 210, 26), // "textFieldValueValueChanged"
QT_MOC_LITERAL(11, 237, 22), // "textFieldLValueChanged"
QT_MOC_LITERAL(12, 260, 22), // "textFieldAValueChanged"
QT_MOC_LITERAL(13, 283, 22), // "textFieldBValueChanged"
QT_MOC_LITERAL(14, 306, 21), // "rectangleColorChanged"
QT_MOC_LITERAL(15, 328, 17), // "setSliderRedValue"
QT_MOC_LITERAL(16, 346, 5), // "value"
QT_MOC_LITERAL(17, 352, 19), // "setSliderGreenValue"
QT_MOC_LITERAL(18, 372, 18), // "setSliderBlueValue"
QT_MOC_LITERAL(19, 391, 20), // "setTextFieldRedValue"
QT_MOC_LITERAL(20, 412, 22), // "setTextFieldGreenValue"
QT_MOC_LITERAL(21, 435, 21), // "setTextFieldBlueValue"
QT_MOC_LITERAL(22, 457, 20), // "setTextFieldHueValue"
QT_MOC_LITERAL(23, 478, 1), // "h"
QT_MOC_LITERAL(24, 480, 1), // "s"
QT_MOC_LITERAL(25, 482, 1), // "v"
QT_MOC_LITERAL(26, 484, 27), // "setTextFieldSaturationValue"
QT_MOC_LITERAL(27, 512, 22), // "setTextFieldValueValue"
QT_MOC_LITERAL(28, 535, 18), // "setTextFieldLValue"
QT_MOC_LITERAL(29, 554, 1), // "l"
QT_MOC_LITERAL(30, 556, 1), // "a"
QT_MOC_LITERAL(31, 558, 1), // "b"
QT_MOC_LITERAL(32, 560, 18), // "setTextFieldAValue"
QT_MOC_LITERAL(33, 579, 18), // "setTextFieldBValue"
QT_MOC_LITERAL(34, 598, 17), // "setRectangleColor"
QT_MOC_LITERAL(35, 616, 5), // "color"
QT_MOC_LITERAL(36, 622, 14), // "sliderRedValue"
QT_MOC_LITERAL(37, 637, 16), // "sliderGreenValue"
QT_MOC_LITERAL(38, 654, 15), // "sliderBlueValue"
QT_MOC_LITERAL(39, 670, 17), // "textFieldRedValue"
QT_MOC_LITERAL(40, 688, 19), // "textFieldGreenValue"
QT_MOC_LITERAL(41, 708, 18), // "textFieldBlueValue"
QT_MOC_LITERAL(42, 727, 17), // "textFieldHueValue"
QT_MOC_LITERAL(43, 745, 24), // "textFieldSaturationValue"
QT_MOC_LITERAL(44, 770, 19), // "textFieldValueValue"
QT_MOC_LITERAL(45, 790, 15), // "textFieldLValue"
QT_MOC_LITERAL(46, 806, 15), // "textFieldAValue"
QT_MOC_LITERAL(47, 822, 15), // "textFieldBValue"
QT_MOC_LITERAL(48, 838, 14) // "rectangleColor"

    },
    "View\0sliderRedValueChanged\0\0"
    "sliderGreenValueChanged\0sliderBlueValueChanged\0"
    "textFieldRedValueChanged\0"
    "textFieldGreenValueChanged\0"
    "textFieldBlueValueChanged\0"
    "textFieldHueValueChanged\0"
    "textFieldSaturationValueChanged\0"
    "textFieldValueValueChanged\0"
    "textFieldLValueChanged\0textFieldAValueChanged\0"
    "textFieldBValueChanged\0rectangleColorChanged\0"
    "setSliderRedValue\0value\0setSliderGreenValue\0"
    "setSliderBlueValue\0setTextFieldRedValue\0"
    "setTextFieldGreenValue\0setTextFieldBlueValue\0"
    "setTextFieldHueValue\0h\0s\0v\0"
    "setTextFieldSaturationValue\0"
    "setTextFieldValueValue\0setTextFieldLValue\0"
    "l\0a\0b\0setTextFieldAValue\0setTextFieldBValue\0"
    "setRectangleColor\0color\0sliderRedValue\0"
    "sliderGreenValue\0sliderBlueValue\0"
    "textFieldRedValue\0textFieldGreenValue\0"
    "textFieldBlueValue\0textFieldHueValue\0"
    "textFieldSaturationValue\0textFieldValueValue\0"
    "textFieldLValue\0textFieldAValue\0"
    "textFieldBValue\0rectangleColor"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_View[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      32,   14, // methods
      13,  268, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
      13,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,  174,    2, 0x06 /* Public */,
       3,    0,  175,    2, 0x06 /* Public */,
       4,    0,  176,    2, 0x06 /* Public */,
       5,    0,  177,    2, 0x06 /* Public */,
       6,    0,  178,    2, 0x06 /* Public */,
       7,    0,  179,    2, 0x06 /* Public */,
       8,    0,  180,    2, 0x06 /* Public */,
       9,    0,  181,    2, 0x06 /* Public */,
      10,    0,  182,    2, 0x06 /* Public */,
      11,    0,  183,    2, 0x06 /* Public */,
      12,    0,  184,    2, 0x06 /* Public */,
      13,    0,  185,    2, 0x06 /* Public */,
      14,    0,  186,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      15,    1,  187,    2, 0x0a /* Public */,
      17,    1,  190,    2, 0x0a /* Public */,
      18,    1,  193,    2, 0x0a /* Public */,
      19,    1,  196,    2, 0x0a /* Public */,
      20,    1,  199,    2, 0x0a /* Public */,
      21,    1,  202,    2, 0x0a /* Public */,
      22,    3,  205,    2, 0x0a /* Public */,
      26,    3,  212,    2, 0x0a /* Public */,
      27,    3,  219,    2, 0x0a /* Public */,
      22,    1,  226,    2, 0x0a /* Public */,
      26,    1,  229,    2, 0x0a /* Public */,
      27,    1,  232,    2, 0x0a /* Public */,
      28,    3,  235,    2, 0x0a /* Public */,
      32,    3,  242,    2, 0x0a /* Public */,
      33,    3,  249,    2, 0x0a /* Public */,
      28,    1,  256,    2, 0x0a /* Public */,
      32,    1,  259,    2, 0x0a /* Public */,
      33,    1,  262,    2, 0x0a /* Public */,
      34,    1,  265,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void, QMetaType::Int,   16,
    QMetaType::Void, QMetaType::Int,   16,
    QMetaType::Void, QMetaType::Int,   16,
    QMetaType::Void, QMetaType::Int,   16,
    QMetaType::Void, QMetaType::Int,   16,
    QMetaType::Void, QMetaType::Int,   16,
    QMetaType::Void, QMetaType::Float, QMetaType::Float, QMetaType::Float,   23,   24,   25,
    QMetaType::Void, QMetaType::Float, QMetaType::Float, QMetaType::Float,   23,   24,   25,
    QMetaType::Void, QMetaType::Float, QMetaType::Float, QMetaType::Float,   23,   24,   25,
    QMetaType::Void, QMetaType::Int,   16,
    QMetaType::Void, QMetaType::Int,   16,
    QMetaType::Void, QMetaType::Int,   16,
    QMetaType::Void, QMetaType::Float, QMetaType::Float, QMetaType::Float,   29,   30,   31,
    QMetaType::Void, QMetaType::Float, QMetaType::Float, QMetaType::Float,   29,   30,   31,
    QMetaType::Void, QMetaType::Float, QMetaType::Float, QMetaType::Float,   29,   30,   31,
    QMetaType::Void, QMetaType::Int,   16,
    QMetaType::Void, QMetaType::Int,   16,
    QMetaType::Void, QMetaType::Int,   16,
    QMetaType::Void, QMetaType::QColor,   35,

 // properties: name, type, flags
      36, QMetaType::Int, 0x00495103,
      37, QMetaType::Int, 0x00495103,
      38, QMetaType::Int, 0x00495103,
      39, QMetaType::Int, 0x00495103,
      40, QMetaType::Int, 0x00495103,
      41, QMetaType::Int, 0x00495103,
      42, QMetaType::Int, 0x00495103,
      43, QMetaType::Int, 0x00495103,
      44, QMetaType::Int, 0x00495103,
      45, QMetaType::Int, 0x00495103,
      46, QMetaType::Int, 0x00495103,
      47, QMetaType::Int, 0x00495103,
      48, QMetaType::QColor, 0x00495103,

 // properties: notify_signal_id
       0,
       1,
       2,
       3,
       4,
       5,
       6,
       7,
       8,
       9,
      10,
      11,
      12,

       0        // eod
};

void View::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<View *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->sliderRedValueChanged(); break;
        case 1: _t->sliderGreenValueChanged(); break;
        case 2: _t->sliderBlueValueChanged(); break;
        case 3: _t->textFieldRedValueChanged(); break;
        case 4: _t->textFieldGreenValueChanged(); break;
        case 5: _t->textFieldBlueValueChanged(); break;
        case 6: _t->textFieldHueValueChanged(); break;
        case 7: _t->textFieldSaturationValueChanged(); break;
        case 8: _t->textFieldValueValueChanged(); break;
        case 9: _t->textFieldLValueChanged(); break;
        case 10: _t->textFieldAValueChanged(); break;
        case 11: _t->textFieldBValueChanged(); break;
        case 12: _t->rectangleColorChanged(); break;
        case 13: _t->setSliderRedValue((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 14: _t->setSliderGreenValue((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 15: _t->setSliderBlueValue((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 16: _t->setTextFieldRedValue((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 17: _t->setTextFieldGreenValue((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 18: _t->setTextFieldBlueValue((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 19: _t->setTextFieldHueValue((*reinterpret_cast< float(*)>(_a[1])),(*reinterpret_cast< float(*)>(_a[2])),(*reinterpret_cast< float(*)>(_a[3]))); break;
        case 20: _t->setTextFieldSaturationValue((*reinterpret_cast< float(*)>(_a[1])),(*reinterpret_cast< float(*)>(_a[2])),(*reinterpret_cast< float(*)>(_a[3]))); break;
        case 21: _t->setTextFieldValueValue((*reinterpret_cast< float(*)>(_a[1])),(*reinterpret_cast< float(*)>(_a[2])),(*reinterpret_cast< float(*)>(_a[3]))); break;
        case 22: _t->setTextFieldHueValue((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 23: _t->setTextFieldSaturationValue((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 24: _t->setTextFieldValueValue((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 25: _t->setTextFieldLValue((*reinterpret_cast< float(*)>(_a[1])),(*reinterpret_cast< float(*)>(_a[2])),(*reinterpret_cast< float(*)>(_a[3]))); break;
        case 26: _t->setTextFieldAValue((*reinterpret_cast< float(*)>(_a[1])),(*reinterpret_cast< float(*)>(_a[2])),(*reinterpret_cast< float(*)>(_a[3]))); break;
        case 27: _t->setTextFieldBValue((*reinterpret_cast< float(*)>(_a[1])),(*reinterpret_cast< float(*)>(_a[2])),(*reinterpret_cast< float(*)>(_a[3]))); break;
        case 28: _t->setTextFieldLValue((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 29: _t->setTextFieldAValue((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 30: _t->setTextFieldBValue((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 31: _t->setRectangleColor((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (View::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&View::sliderRedValueChanged)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (View::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&View::sliderGreenValueChanged)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (View::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&View::sliderBlueValueChanged)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (View::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&View::textFieldRedValueChanged)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (View::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&View::textFieldGreenValueChanged)) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (View::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&View::textFieldBlueValueChanged)) {
                *result = 5;
                return;
            }
        }
        {
            using _t = void (View::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&View::textFieldHueValueChanged)) {
                *result = 6;
                return;
            }
        }
        {
            using _t = void (View::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&View::textFieldSaturationValueChanged)) {
                *result = 7;
                return;
            }
        }
        {
            using _t = void (View::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&View::textFieldValueValueChanged)) {
                *result = 8;
                return;
            }
        }
        {
            using _t = void (View::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&View::textFieldLValueChanged)) {
                *result = 9;
                return;
            }
        }
        {
            using _t = void (View::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&View::textFieldAValueChanged)) {
                *result = 10;
                return;
            }
        }
        {
            using _t = void (View::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&View::textFieldBValueChanged)) {
                *result = 11;
                return;
            }
        }
        {
            using _t = void (View::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&View::rectangleColorChanged)) {
                *result = 12;
                return;
            }
        }
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        auto *_t = static_cast<View *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< int*>(_v) = _t->getSliderRedValue(); break;
        case 1: *reinterpret_cast< int*>(_v) = _t->getSliderGreenValue(); break;
        case 2: *reinterpret_cast< int*>(_v) = _t->getSliderBlueValue(); break;
        case 3: *reinterpret_cast< int*>(_v) = _t->getTextFieldRedValue(); break;
        case 4: *reinterpret_cast< int*>(_v) = _t->getTextFieldGreenValue(); break;
        case 5: *reinterpret_cast< int*>(_v) = _t->getTextFieldBlueValue(); break;
        case 6: *reinterpret_cast< int*>(_v) = _t->getTextFieldHueValue(); break;
        case 7: *reinterpret_cast< int*>(_v) = _t->getTextFieldSaturationValue(); break;
        case 8: *reinterpret_cast< int*>(_v) = _t->getTextFieldValueValue(); break;
        case 9: *reinterpret_cast< int*>(_v) = _t->getTextFieldLValue(); break;
        case 10: *reinterpret_cast< int*>(_v) = _t->getTextFieldAValue(); break;
        case 11: *reinterpret_cast< int*>(_v) = _t->getTextFieldBValue(); break;
        case 12: *reinterpret_cast< QColor*>(_v) = _t->getRectangleColor(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        auto *_t = static_cast<View *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setSliderRedValue(*reinterpret_cast< int*>(_v)); break;
        case 1: _t->setSliderGreenValue(*reinterpret_cast< int*>(_v)); break;
        case 2: _t->setSliderBlueValue(*reinterpret_cast< int*>(_v)); break;
        case 3: _t->setTextFieldRedValue(*reinterpret_cast< int*>(_v)); break;
        case 4: _t->setTextFieldGreenValue(*reinterpret_cast< int*>(_v)); break;
        case 5: _t->setTextFieldBlueValue(*reinterpret_cast< int*>(_v)); break;
        case 6: _t->setTextFieldHueValue(*reinterpret_cast< int*>(_v)); break;
        case 7: _t->setTextFieldSaturationValue(*reinterpret_cast< int*>(_v)); break;
        case 8: _t->setTextFieldValueValue(*reinterpret_cast< int*>(_v)); break;
        case 9: _t->setTextFieldLValue(*reinterpret_cast< int*>(_v)); break;
        case 10: _t->setTextFieldAValue(*reinterpret_cast< int*>(_v)); break;
        case 11: _t->setTextFieldBValue(*reinterpret_cast< int*>(_v)); break;
        case 12: _t->setRectangleColor(*reinterpret_cast< QColor*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
}

QT_INIT_METAOBJECT const QMetaObject View::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_View.data,
    qt_meta_data_View,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *View::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *View::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_View.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int View::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 32)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 32;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 32)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 32;
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 13;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 13;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 13;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 13;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 13;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 13;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void View::sliderRedValueChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void View::sliderGreenValueChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void View::sliderBlueValueChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}

// SIGNAL 3
void View::textFieldRedValueChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 3, nullptr);
}

// SIGNAL 4
void View::textFieldGreenValueChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 4, nullptr);
}

// SIGNAL 5
void View::textFieldBlueValueChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 5, nullptr);
}

// SIGNAL 6
void View::textFieldHueValueChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 6, nullptr);
}

// SIGNAL 7
void View::textFieldSaturationValueChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 7, nullptr);
}

// SIGNAL 8
void View::textFieldValueValueChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 8, nullptr);
}

// SIGNAL 9
void View::textFieldLValueChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 9, nullptr);
}

// SIGNAL 10
void View::textFieldAValueChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 10, nullptr);
}

// SIGNAL 11
void View::textFieldBValueChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 11, nullptr);
}

// SIGNAL 12
void View::rectangleColorChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 12, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
