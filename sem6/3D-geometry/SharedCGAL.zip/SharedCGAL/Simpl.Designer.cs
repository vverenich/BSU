﻿
namespace SharedCGAL
{
    partial class Simpl
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBoxStep = new System.Windows.Forms.TextBox();
            this.lbl_12 = new System.Windows.Forms.Label();
            this.Cancel = new System.Windows.Forms.Button();
            this.Run = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textBoxStep
            // 
            this.textBoxStep.Location = new System.Drawing.Point(202, 16);
            this.textBoxStep.Name = "textBoxStep";
            this.textBoxStep.Size = new System.Drawing.Size(77, 20);
            this.textBoxStep.TabIndex = 29;
            this.textBoxStep.Text = "100";
            // 
            // lbl_12
            // 
            this.lbl_12.AutoSize = true;
            this.lbl_12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbl_12.Location = new System.Drawing.Point(13, 19);
            this.lbl_12.Name = "lbl_12";
            this.lbl_12.Size = new System.Drawing.Size(63, 13);
            this.lbl_12.TabIndex = 28;
            this.lbl_12.Text = "parameter";
            // 
            // Cancel
            // 
            this.Cancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.Cancel.Location = new System.Drawing.Point(158, 42);
            this.Cancel.Name = "Cancel";
            this.Cancel.Size = new System.Drawing.Size(121, 42);
            this.Cancel.TabIndex = 27;
            this.Cancel.Text = "Cancel";
            this.Cancel.UseVisualStyleBackColor = true;
            // 
            // Run
            // 
            this.Run.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.Run.Location = new System.Drawing.Point(11, 42);
            this.Run.Name = "Run";
            this.Run.Size = new System.Drawing.Size(121, 42);
            this.Run.TabIndex = 26;
            this.Run.Text = "Run";
            this.Run.UseVisualStyleBackColor = true;
            // 
            // Simpl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(286, 90);
            this.Controls.Add(this.textBoxStep);
            this.Controls.Add(this.lbl_12);
            this.Controls.Add(this.Cancel);
            this.Controls.Add(this.Run);
            this.Name = "Simpl";
            this.Text = "Simpl";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.TextBox textBoxStep;
        private System.Windows.Forms.Label lbl_12;
        private System.Windows.Forms.Button Cancel;
        private System.Windows.Forms.Button Run;
    }
}