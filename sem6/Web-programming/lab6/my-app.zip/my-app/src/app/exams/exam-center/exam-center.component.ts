import { Component } from '@angular/core';

@Component({
  selector: 'app-exam-center',
  templateUrl: './exam-center.component.html',
  styleUrls: ['./exam-center.component.css']
})
export class ExamCenterComponent {

}
